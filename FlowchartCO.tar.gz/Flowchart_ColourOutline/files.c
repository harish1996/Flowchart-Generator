#ifndef _STDIO_H

#include<stdio.h>

#endif

#ifndef _STDLIB_H

#include<stdlib.h>

#endif

#ifndef _FILES

#ifndef VALIDATE

#define VALIDATE(a,b) 	if(a==NULL)\
				{\
					printf("Unable to access memory");\
					return b;\
				}

#endif

#define _FILES           1
#define WRITE_BIN		"wb"
#define READ_BIN        "rb"
#define APPEND_BIN      "ab"
#define READ            "r"
#define WRITE           "w"
#define APPEND          "a"

#endif

#ifndef _SPECIAL_CHARS

#define _SPECIAL_CHARS   1
#define NULL_CHAR       '\0'
#define SPACE           ' '
#define RETURN          '\n'
#define BACKSPACE       127

#endif
/*
Function to determine the filesize of the given file
Arguments : File name
Returns   : Size of the file
*/
unsigned long int filesize(char *fn)
{
	unsigned long int len;
	FILE *fp=fopen(fn,READ);
	VALIDATE(fp,0);
	fseek(fp,0,SEEK_END);												//Place file pointer at the last position
	len = (unsigned long int )ftell(fp);						 // Tell the position of the file pointer relative to the file
	fclose(fp);
	return len;
}


/*
 Function which copies the entire contents of the file to a character buffer
 Arguments : File name
 Returns   : Array of characters containing file contents
 */
char* copy_buffer(char *fn)
{
	unsigned long int len=filesize(fn);
	char *buffer=(char *)malloc(len*sizeof(char)+1); 				// Allocating memory for buffer including the null character
	VALIDATE(buffer,NULL)
	FILE *fp=fopen(fn,READ);
	VALIDATE(fp,NULL);
	fread(buffer,sizeof(char)*len,1,fp);								//Read contents of file and store in buffer
	buffer[len]=NULL_CHAR;											//Append null character to terminate string
	fclose(fp);
	return buffer;
}

