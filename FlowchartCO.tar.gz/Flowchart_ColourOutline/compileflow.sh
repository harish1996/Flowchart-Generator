#! /bin/bash
gcc -Wall -g -c -lm drawstart.c  
gcc -Wall -g -c  -lm elements.c 
ar -r  flowchart.a drawstart.o elements.o
gcc  -Wall drawflow.c -o drawflow.o flowchart.a -lm
 
