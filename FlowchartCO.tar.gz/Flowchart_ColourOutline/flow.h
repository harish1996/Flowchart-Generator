#define HORIZONTAL_FIRST  	1
#define VERTICAL_FIRST   	 	0

#define _FLOW_H 					1

#define FIRST						1
#define SECOND  					2
#define THIRD						3
#define FOURTH					4


 #define TERMINATORS 			1
 #define PROCESS     				2
 #define IO          					3
 #define DECISION    				4
 #define EXISTING	   				5
 
 #define YES_BRANCH 			0
 #define NO_BRANCH   			1
 
 #define WRITE_FILE 				"Endpoints.bmp"

#ifdef BYTES_PER_PIXEL
#undef BYTES_PER_PIXEL
#endif

#define BYTES_PER_PIXEL 		3

#define WHITE 						0xFF
#define BLACK						0x00
#define GRAY 						0x02

#define ZERO_XS 					497
#define ZERO_YS 					497

#define LEFT						1
#define RIGHT     					2

#define UP							1
#define DOWN						2


 
 typedef struct
 {
 	UINT x;
 	UINT y;
 }coordinates;
 
 typedef struct 
 {
 	coordinates top;
 	coordinates right;
 	coordinates left;
 	coordinates bottom;
 	USINT status;
 }positions;

typedef struct flow_element
 {
 	int element_id;
 	int type;
 	int col;
 	struct flow_element *yes;
 	struct flow_element *no;
 	struct flow_element *top;
 	positions pos;
 			
 }element;
 
/*
Function which fills the values of buffer such that to draw an axis 
Arguments : Image buffer , X offset , Y offset , Thickness 
Returns   : Status of the fill operation
*/
USINT drawaxis(UCHAR* image);


/*
Function to fill values in the buffer to draw an arc
Arguments : Image buffer , X offset , Y Offset of the midpoint , Radius of arc , Quadrant of arc
Returns   : Status of fill operation
*/
positions draw_arc(UCHAR* image,UINT x_offset,UINT y_offset,UINT radius,USINT quadrant);


/*
Function which fills the values of buffer such that to draw a circle
Arguments : Image buffer , X offset of center , Y offset of center , Radius 
Returns   : Status of draw operation
*/
positions drawcircle(UCHAR* image,UINT x_offset,UINT y_offset,UINT radius);


/*
Function which fills the values of the buffer to generate a rectangle
Arguments : Image buffer , X offset of left corner , Y offset of left corner , horizontal length , vertical length , thickness
Returns   : Status of draw operation
*/
positions drawrectangle(UCHAR* image,UINT x_offset,UINT y_offset,UINT h_length,UINT v_length,UINT thickness);


/*Draws a straight line between two specified coordinates in the given color
Arguments : Image buffer , X offset 1 , Y offset 1 , X offset 2 , Y offset 2 , Thickness , Colour of the line
Returns   : Status of draw
*/
USINT line_segment(UCHAR* image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , UINT thickness , UCHAR *color);


/*
Function to fill values in the buffer to draw a paralellogram
Arguments : Image buffer , X offset , Y offset of the topleft corner , Angle of tilt , length , breadth , thickness
Returns   : Status of the draw operation
*/
positions paralellogram(UCHAR *image,UINT x_offset,UINT y_offset,int angledeg,UINT h_length,UINT v_length,UINT thickness);



/*
Function to fill the values draw a rhombus
Arguments : Image buffer , X Offset ,Y offset of the top corner , size , thickness
Returns   : Status of the draw operation
*/
positions rhombus(UCHAR* image, UINT x_offset , UINT y_offset , UINT size , UINT thickness );



/* Function to fill values to draw an arrowhead
Arguments : Image buffer , X coordinate , Y coordinates of start and end , First direction
Returns   : Status of the draw operation
*/
positions arrow(UCHAR *image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , USINT first );


//Function to fill values to generate a triple bend arrow
//Arguments :Image buffer , X,Y coordinates of start and end points , First direction
//Returns   : Status of draw operation
positions tb_arrow(UCHAR* image,UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , USINT first, USINT side);

//Function to fill values to draw a triply bent arrow
//Arguments : Image buffer, X,Y coordinates of start and end points , First direction , First side
//Returns      : Structure consisiting of position of start and end of the arrow
positions trb_arrow(UCHAR* image,UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , USINT first, USINT side);

/*
Function to fill values in the buffer to draw a rounded rectangle
Arguments : Image buffer, X offset , Y offset of midpoint of top side , horizontal length , vertical length 
Returns   : Status of the draw operation
*/
positions round_rect(UCHAR *image,UINT x_offset , UINT y_offset , UINT h_length , UINT v_length);

 /*
 Function to create an element with proper attributes and returns the element
 Arguments : Type of element , Column of the element , Top element after which element is present
 Returns   : Pointer to the element
 */
 element* create_element (int type,int col,element* top);
 
  /* 
 Function to create an arrow between two elements
 Arguments : Pointer to starting element and terminating element
 Returns   : Pointer to the arrow element
 */
 void create_arrow(element* top , element* bottom);
 
  /*
 Function to display all the elements created till that instant
 Arguments : Root from which elements should be displayed
 Returns   : None
 */
 void display_elements(element* root);
 
 /* 
Function which searches for a specific element ID and returns the address
Arguments : Element ID , root
Returns   : Element Address( NULL if not found ) 
*/
element* find_element(int id,element *root);

/*
Function to add a new element next to the current element
Arguments : Pointer to the root , Column of addition
Returns   : Nothing 
*/ 
 int add_elements(element *now,int branch);
 
 
