#ifndef VALIDATE

#define VALIDATE(a,b) 	if(a==NULL)\
				{\
					printf("Unable to access memory");\
					return b;\
				}

#endif
#define _IMAGING_H 	1
#define UCHAR		unsigned char
#define USINT		unsigned short int
#define UINT		unsigned int

#ifndef INITIALISE
#define INITIALISE	0
#endif

#ifndef _FILES

#define _FILES           1
#define WRITE_BIN		"wb"
#define READ_BIN        "rb"
#define APPEND_BIN      "ab"
#define READ            "r"
#define WRITE           "w"
#define APPEND          "a"

#endif

#ifndef IMAGE      
    
#define IMAGE           'bmp'
#define BYTES_PER_PIXEL 3
#define WIDTH		1000

#define VIOLET		148,0,211
#define INDIGO		75,0,130
#define BLUE		0,0,255
#define GREEN		0,255,0
#define YELLOW		255,255,0
#define ORANGE		255,127,0
#define RED          255,0,0
#define WHITE_RGB   255,255,255
#define BLACK_RGB    0,0,0
#define GRAY_RGB    127,127,127
#define SEA_GREEN   48,128,20
#define BROWN		139,105,20

#define BPP_RGB888      24
#define BPP_RGB565		16
#define BPP_MONO        8

#define PPM             3700

#define HEADER_SIZE	54

#define SIGNATURE		0x4D42

#endif

#ifndef SPECIAL_CHARS

#define SPECIAL_CHARS   1
#define NULL_CHAR       '\0'
#define SPACE           ' '
#define RETURN          '\n'
#define BACKSPACE       127

#endif

#pragma pack(1)

typedef struct
{
	USINT signature;                                                   //Signature=4D42
	UINT size;                                                         //Size of BMP file
	UINT reserved;                                                     //Reserved bytes . Always 00000000
	UINT offset;                                                       //Offset to start of image 
	UINT structuresize;                                                //Size of image header structure . Must be 40 for BMP
	UINT width;                                                        //Image Width in pixels
	int height;                                                       //Image Height in pixels
	USINT planes;                                                      // No.of planes . 1 in BMP
	USINT bpp;                                                         //Bits per pixel (1,4,8 or 24 )
	UINT compression;                                                  //Compression type (0=none , 1=RLE-8 , 2=RLE-4 )
	UINT size_of_image;                                                //Size of image data
	UINT hpm;                                                          //Horizontal pixels per meter
	UINT vpm;                                                          //Vertical pixels per meter
	UINT colors;                                                       // Number of colors or zero
	UINT imp_colors;                                                   // Number of important colors or zero
}header;	

typedef union
{
 	struct
 	{
 		unsigned short int bit:5;
 		unsigned short int bit1:6;
 		unsigned short int bit2:5;
 	}bits;
 	unsigned short int word;
 	
}field;

unsigned char fill_header ( char *fn , int height , int width , int bpp , int ppm , int pallete_size);

UCHAR fill_pallete(char *fn);

//UCHAR fill_image(UCHAR *image,char *fn,int height,int width,int bpp);

UCHAR* assign_MONO(int grayscale);

UCHAR* assign_RGB888(USINT red, USINT green , USINT blue);

UCHAR* assign_RGB565(USINT red, USINT green , USINT blue);
