 #ifndef _STDIO_H
 #include<stdio.h>
 #endif
 #ifndef _STDLIB_H
 #include<stdlib.h>
 #endif
 #ifndef _STRING_H
 #include<string.h>
 #endif
 /*#ifndef _FILES
 #include"files.c"
 #endif*/
 #ifndef _IMAGING_H
 #include"imaging.h"
 #endif
 #ifndef _FLOW_H
 #include"flow.h"
 #endif
 #ifndef _MATH_H
 #include<math.h>
 #endif
 
  #define _ELEMENTS   				1
 
 
extern element *head,*current;
extern int row;
extern int HEIGHT;
 
 
 /*
 Function to create an element with proper attributes and returns the element
 Arguments : Type of element , Column of the element , Top element after which element is present
 Returns   : Pointer to the element
 */
 element* create_element (int type,int col,element* top)
 {
 	static int id=1;
 	element* new = (element*)malloc(sizeof(element));
 	VALIDATE(new,NULL);
 	new->element_id = id;
 	id++;
 	new->type= type;
 	new->col=col;
 	new->top=top;
 	new->yes=NULL;
 	new->no=NULL;
 	row++;
 	return new;
 }
 
 /*
 Function to display all the elements created till that instant
 Arguments : Root from which elements should be displayed
 Returns   : None
 */
 void display_elements(element* root)
 {
	int el_id_y,el_id_n;
 	printf("\n\n\n");
 	//printf("Entering display as %p\n",root);
 	while(root!=NULL)
 	{
 		printf("\t\t\t%d %d  ",root->element_id,root->col);
 		if(root->yes ==NULL)
 		{
 			el_id_y=0;
 		}
 		else
 		{
 			el_id_y=root->yes->element_id;
 		}
 		if(root->no ==NULL)
 		{
 			el_id_n=0;
 		}
 		else
 		{
 			el_id_n=root->no->element_id;
 		}
	 	switch(root->type)
		{	 	
			case TERMINATORS :{
 							if(root->top ==NULL)
 								printf("Start --> %d\n",el_id_y);
 							else if(root->yes ==NULL)
 								printf("Stop\n");
 							else
 							{	printf("Invalid terminal found");
 								return;
 							}
 						}break;
 			case PROCESS     :{
 							printf("Process --> %d\n",el_id_y);
 						}break;
 			case IO          :{
 							printf("I/O Operations --> %d\n",el_id_y);
 						}break;
 			case DECISION    :{
 							printf("%d <-yes-- DECISION --no-> %d\n",el_id_y,el_id_n);
 						}break;
 		}
 		if(root->type != DECISION && root->yes != NULL)
 		{
 			//printf("Inside traverse\n");
 			if(root->yes->element_id <= root->element_id) root=NULL;
 			else
 			{
 				root=root->yes;
 			}
 		}
 		else if(root->type == DECISION )
 		{
 			//printf("End encountered in Decision\n");
 			if(root->yes->element_id > root->element_id) display_elements(root->yes);
 			//printf("After yes\n");
 			//printf("%p",root->no);
 			if(root->no != NULL)
 			{
 				if(root->no->element_id > root->element_id)  display_elements(root->no);
 				//printf("After no\n");
 			}
 			return ;
 		}
 		else 
 		{
 			printf("End encountered\n");
 			return;
 		}
 	}
 }
 
 
 
/* 
Function which searches for a specific element ID and returns the address
Arguments : Element ID , root
Returns   : Element Address( NULL if not found ) 
*/
element* find_element(int id,element *root)
{
	element* ret;
	while( root!=NULL)
	{
		if(root->element_id == id )
			return root;
		else if(root->yes!=NULL && root->type!=DECISION )
		{
			root=root->yes;
		}
		else if(root->type== DECISION )
		{
			if(root->yes!=NULL)
				ret=find_element(id,root->yes);
			else ret=NULL;
			if(ret==NULL)
			{
				if(root->no!=NULL)
					ret=find_element(id,root->no);
				else ret=NULL;
				return ret;
			}
			else return ret;
		}
		else
		{
			return NULL;
		}
	}
	return NULL;
}		
		


/*
Function to add a new element next to the current element
Arguments : Pointer to the root , Column of addition
Returns   : The number of columns  
*/ 
 int add_elements(element *now,int branch)
 {
	static int col=1;
	int choice,dummy;
	int end=1;
	int id_choice;
	while(end==1)
	{
		printf("Enter the next element to be added\n");
		printf(" 1. Stop \n");
		printf(" 2. Process Box \n");
		printf(" 3. I/O Box \n");
		printf(" 4. Decision Box \n");
		printf(" 5. Connect to existing box \n");
		scanf("%d",&choice);
		switch(choice)
		{
			case TERMINATORS :
			case PROCESS     :
			case IO          : 
						{
							//printf("Entering create element");
							if(branch==YES_BRANCH)
							{
								now->yes=create_element(choice,col,now);
								//printf("Created as Yes %p  %p ",now,now->yes);
								now=now->yes;
								//printf(" Now %p and yes %p",now,now->yes);
								
							}
							else
							{
								now->no=create_element(choice,col,now);
								//printf("Created as No %p  %p ",now,now->no);
								now=now->no;
								//printf(" Now %p and yes %p",now,now->yes);
							}
							if(choice==TERMINATORS)
								end=0;
								
						}break;
			case DECISION    :
						{
							if(branch==YES_BRANCH)
							{
								now->yes=create_element(choice,col,now);
								now=now->yes;
							}
							else
							{
								now->no=create_element(choice,col,now);
								now=now->no;
							}
							printf(" Adding blocks for Yes Branch for Element %d \n",now->element_id);
							//printf("Before adding element\n");
							dummy=add_elements(now,YES_BRANCH);
							printf("After adding element\n");
							printf(" Adding blocks for No Branch for Element %d \n",now->element_id);
							col++;
							dummy=add_elements(now,NO_BRANCH);
							end=0;
						}break;
			case EXISTING    :
			  			{
				  			printf(" Enter the id of the element to which connection is to be made \n");
			  				scanf("%d",&id_choice);

			  				if(branch==YES_BRANCH)
			  				{
				  				now->yes=find_element(id_choice,head);
				  				if(now->yes==NULL)
				  					printf(" Id could not be found , Enter again !! \n");
				  				else
				  					end=0;
			  				}
			  				else
			  				{
			  					now->no=find_element(id_choice,head);
				  				if(now->no==NULL)
				  					printf(" Id could not be found , Enter again !! \n");
				  				else
				  					end=0;
				  			}
			  			}break;
			 default		:
			 			{	printf("Enter valid option");
			 			}
		}
		printf("\n\n \t\t\tFinal Flow diagram is \n");
		display_elements(head);
		branch=YES_BRANCH;
	}
	return col;
}	
