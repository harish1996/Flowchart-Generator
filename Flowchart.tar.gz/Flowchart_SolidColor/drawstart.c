 #ifndef _STDIO_H
 #include<stdio.h>
 #endif
 #ifndef _STDLIB_H
 #include<stdlib.h>
 #endif
 #ifndef _STRING_H
 #include<string.h>
 #endif
 #ifndef _FILES
 #include"files.c"
 #endif
 #ifndef _IMAGING_H
 #include"imaging.h"
 #endif
 #ifndef _FLOW_H
 #include"flow.h"
 #endif
 #ifndef _MATH_H
 #include<math.h>
 #endif

#define _DRAWSTART 				1

#define VALID_LINE(a,b)			if(a==0)\
								{\
									return b;\
								}

#define FILL_RGB888(xoff,yoff)		memcpy((image+((xoff)*BPP_RGB888/8)+((yoff)*WIDTH*BPP_RGB888/8)),color,BPP_RGB888/8)
#define ARROW_THICK				3
extern int HEIGHT;
extern int row;
int roffset=8,loffset=8;
/*
Function to fill the header of the Bitmap file
Arguments : Image file name, Height of the image , Width , Bits per pixel , pixels per meter
Returns   : 'Character' Status of the write operation
*/	
unsigned char fill_header ( char *fn , int height , int width , int bpp , int ppm, int pallete_size )
{
	header head;
	head.signature=(USINT)SIGNATURE;
	head.size=(UINT)height*width*(bpp/8)+HEADER_SIZE+pallete_size;				
	head.reserved = (UINT)0;
	head.offset =(UINT)HEADER_SIZE+pallete_size;
	head.structuresize =(UINT)40;
	head.width=(UINT)width;
	head.height=-(height);
	head.planes=(USINT)1;
	head.bpp=(USINT)bpp;
	head.compression=(UINT)0;
	head.size_of_image=(UINT)head.size-HEADER_SIZE-pallete_size;
	head.hpm=(UINT)ppm;
	head.vpm=(UINT)ppm;
	head.colors=(UINT)pallete_size/4;
	head.imp_colors=(UINT)0;
	FILE *fp=fopen(fn,WRITE_BIN);
	VALIDATE(fp,0);
	fwrite(&head,HEADER_SIZE,1,fp);
	fclose(fp);
	return 1;
}


UCHAR fill_pallete(char *fn)
{
	UCHAR* pallete=(UCHAR*)malloc(1024*sizeof(UCHAR));
	UCHAR*  pall=pallete;
	for(int i=0;i<256;i++)
	{
		*(pallete)=(UCHAR)i;
		*(pallete+1)=(UCHAR)i;
		*(pallete+2)=(UCHAR)i;
		*(pallete+3)=(UCHAR)i;
		pallete+=4;
	}
	FILE *fp=fopen(fn,APPEND_BIN);
	VALIDATE(fp,0);
	fwrite(pall,1024,1,fp);
	fclose(fp);
	free(pall);
	return 1;
}
	
/*UCHAR fill_image(UCHAR *image,char *fn,int width,int height,int bpp)
{
	UCHAR *temp=(UCHAR*)malloc(width*sizeof(UCHAR));
	printf(" Inside fill image\n");
	for(int i=0;i<(height/2);i++)
	{	
		printf("Inside loop %d %d\n",i,height-i-1);
		memcpy(temp,(image+(i*width*bpp)),width*bpp);
		printf("After 1st\n");
		memcpy((image+(i*width*bpp)),(image+((height-i-1)*width*bpp)),width*bpp);
		printf("After 2nd\n");
		memcpy((image+((height-i-1)*width*bpp)),temp,width*bpp);
		printf("After 3rd\n");
	}
	
	FILE *fp=fopen(fn,APPEND_BIN);
	VALIDATE(fp,0);
	fwrite(image,height*width*bpp,1,fp);
	free(temp);
	fclose(fp);
	return 1;
}*/
/* 
Assign Grayscale values to 1 byte and returns the array
Arguments : Grayscale
Returns   : Character array with Grayscale value
*/
unsigned char* assign_MONO ( int grayscale)
{
	UCHAR *color=(UCHAR*)malloc(BYTES_PER_PIXEL*sizeof(unsigned char));
	VALIDATE(color,NULL);
	*(color)=grayscale;
	return color;
}

/* 
Assign RGB values to 3 bytes and returns the array
Arguments : Red , Green , Blue values
Returns   : Array containing RGB value
*/
UCHAR* assign_RGB888(USINT red,USINT green,USINT blue)
{
	UCHAR *color=(UCHAR*)malloc(BPP_RGB888/8*sizeof(UCHAR));
	printf("%d %d %d",red,green,blue);
	VALIDATE(color,NULL);
	*(color)=(UCHAR)blue;
	*(color+1)=(UCHAR)green;
	*(color+2)=(UCHAR)red;
	return color;
}

/* 
Assign RGB values to 2 bytes(RGB 565) and returns the array
Arguments : Red , Green , Blue values
Returns   : Array containing RGB_565 value
*/
UCHAR* assign_RGB565(USINT red,USINT green,USINT blue)
{
	UCHAR *color=(UCHAR*)malloc(BPP_RGB565/8*sizeof(UCHAR));
	field rgb;
	VALIDATE(color,NULL);
	rgb.bits.bit=(red>>3);
	rgb.bits.bit1=(green>>2);
	rgb.bits.bit2=(blue>>3);
	memcpy(color,&rgb.word,BPP_RGB565/8*sizeof(UCHAR));
	return color;
}
/*
Function which fills the values of buffer such that to draw an axis 
Arguments : Image buffer , X offset , Y offset , Thickness 
Returns   : Status of the fill operation
*/
USINT drawaxis(UCHAR* image)
{	
		UCHAR *color=assign_RGB888(WHITE_RGB);
		for(int i=0;i<HEIGHT;i++)
		{
			for(int j=0;j<WIDTH;j++)
			{
					FILL_RGB888(j,i);
			}
		}
		free(color);
		return 1;
}

/*
Function to fill values in the buffer to draw an arc
Arguments : Image buffer , X offset , Y Offset of the midpoint , Radius of arc , Quadrant of arc
Returns   : Status of fill operation
*/
positions draw_arc(UCHAR* image,UINT x_offset,UINT y_offset,UINT radius,USINT quadrant)
{
	UCHAR *color=assign_RGB888(VIOLET);
	radius*=10;
	UINT y=0;
	UINT prevy=0;
	int diff=0;
	int x_off;
	int y_off;
	int prevy_off;
	positions a;
	if(radius>HEIGHT/2 || radius>=WIDTH/2)
		{
			a.status=0;	
			return a;
		}
	else
	{
		for(int x=0;x<=radius;x++)
		{
			prevy=y;
			y=(UINT)sqrt((float)radius*radius-(float)x*x);
			if(x==0)
			{
				a.top.x=x_offset;
				a.bottom.x=x_offset;
				a.top.y=y_offset-y;
				a.bottom.y=y_offset+y;
			}
			if(x==radius)
			{
				a.right.x=x_offset+radius;
				a.left.x=x_offset-radius;
				a.right.y=y_offset;
				a.left.y=y_offset;
			}
			
			diff=prevy-y;
			switch(quadrant)
			{
				case FIRST :
							{	
								x_off=x_offset+x;
								y_off=y_offset-y;
								prevy_off=y_offset-prevy;
							}break;
				case SECOND :
							{
								x_off=x_offset-x;
								y_off=y_offset-y;
								prevy_off=y_offset-prevy;
							}break;
				case THIRD  :
							{
								x_off=x_offset-x;
								y_off=y_offset+y;
								prevy_off=y_offset-prevy;
							}break;
				case FOURTH :
							{
								x_off=x_offset+x;
								y_off=y_offset+y;
								prevy_off=y_offset+prevy;
							}break;
				default     : 	{
								a.status=0;
								return a;
							}
			}
			//printf("Entering arc  %d   %d   %d \n",x_off,y_off,prevy_off);
			//FILL_RGB888(x_off,y_off);
			//FILL_RGB888(x_off,y_off+1);
			//FILL_RGB888(x_off,y_off-1);
				//USINT line_segment(UCHAR* image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , UINT thickness ,UCHAR* color)
				line_segment(image,x_off,y_offset,x_off,y_off,1,color);
			/*if(diff>2)
			{
					for(int i=0;i<=diff-2;i++)
					{
						FILL_RGB888(x_off,y_off+i);
						FILL_RGB888(x_off,prevy_off+i);
					}
			}	
			if(diff>4)
			{
				for(int i=0;i<=diff-2;i++)
				{
					FILL_RGB888(x_off+1,y_off+i);
					FILL_RGB888(x_off+1,prevy_off+i);
				}
			}*/
		}
	}
	free(color);
	a.status=1;
	return a;
	
}




/*						
Function which fills the values of buffer such that to draw a circle
Arguments : Image buffer , X offset of center , Y offset of center , Radius 
Returns   : Status of draw operation
*/
positions drawcircle(UCHAR* image,UINT x_offset,UINT y_offset,UINT radius)
{
	UCHAR* color=assign_RGB888(GRAY_RGB);
	radius*=10;
	UINT y=0;
	UINT prevy=0;
	int diff=0;
	positions a;
	a.status=0;
	if(radius>HEIGHT/2 || radius>=WIDTH/2)
		return a;
	else
	{
		for(int x=0;x<=radius;x++)
		{
			prevy=y;
			y=(UINT)sqrt((float)radius*radius-(float)x*x);
			diff=prevy-y;
			if(x==0)
			{
				a.top.x=x_offset;
				a.bottom.x=x_offset;
				a.top.y=y_offset-y;
				a.bottom.y=y_offset+y;
			}
			if(x==radius)
			{
				a.right.x=x_offset+radius;
				a.left.x=x_offset-radius;
				a.right.y=y_offset;
				a.left.y=y_offset;
			}
			FILL_RGB888(x_offset+x,y_offset-y);	// First
			FILL_RGB888(x_offset+x,y_offset+y);// Fourth
			FILL_RGB888(x_offset-x,y_offset-y);// Second
			FILL_RGB888(x_offset-x,y_offset+y);// Third
			FILL_RGB888(x_offset+x,y_offset-y+1); // First
			FILL_RGB888(x_offset+x,y_offset+y+1); // Fourth
			FILL_RGB888(x_offset-x,y_offset-y+1); //Second
			FILL_RGB888(x_offset-x,y_offset+y+1); // Third
			FILL_RGB888(x_offset+x,y_offset-y-1);// First
			FILL_RGB888(x_offset+x,y_offset+y-1);//Fourth
			FILL_RGB888(x_offset-x,y_offset-y-1);//Second
			FILL_RGB888(x_offset-x,y_offset+y-1);//Third
			if(diff>2)
			{
				for(int i=0;i<=diff-2;i++)
				{
					FILL_RGB888(x_offset+x,y_offset-y+i);// First
					FILL_RGB888(x_offset+x,y_offset+y-i);//Fourth
					FILL_RGB888(x_offset-x,y_offset-y+i);//Second
					FILL_RGB888(x_offset-x,y_offset+y-i);//Third
					FILL_RGB888(x_offset+x,prevy+y_offset-y+i);// First
					FILL_RGB888(x_offset+x,prevy+y_offset+y-i);//Fourth
					FILL_RGB888(x_offset-x,prevy+y_offset-y+i);//Second
					FILL_RGB888(x_offset-x,prevy+y_offset+y-i);//Third
				}
			}
			if(diff>4)
			{
				for(int i=0;i<=diff-2;i++)
				{
					FILL_RGB888(x_offset+x+1,y_offset-y+i);// First
					FILL_RGB888(x_offset+x+1,y_offset+y-i);//Fourth
					FILL_RGB888(x_offset-x+1,y_offset-y+i);//Second
					FILL_RGB888(x_offset-x+1,y_offset+y-i);//Third
					FILL_RGB888(x_offset+x+1,prevy+y_offset-y+i);// First
					FILL_RGB888(x_offset+x+1,prevy+y_offset+y-i);//Fourth
					FILL_RGB888(x_offset-x+1,prevy+y_offset-y+i);//Second
					FILL_RGB888(x_offset-x+1,prevy+y_offset+y-i);//Third
				}
			}
		}
		free(color);
		a.status=1;
		return a;
	}
}
		


/*
Function which fills the values of the buffer to generate a rectangle
Arguments : Image buffer , X offset of left corner , Y offset of left corner , horizontal length , vertical length , thickness
Returns   : Status of draw operation
*/
positions drawrectangle(UCHAR* image,UINT x_offset,UINT y_offset,UINT h_length,UINT v_length,UINT thickness)
{
	UCHAR* color=assign_RGB888(INDIGO);
	h_length*=10;
	v_length*=10;
	positions a;
	a.status=0;
	if((x_offset+h_length)>WIDTH || (y_offset+v_length)>HEIGHT )
	{
		printf(" Insufficient image size");
		return a;
	}
	else
	{
		/*for(int j=0;j<thickness;j++)
		{
			for(int i=0;i<h_length;i++)
				FILL_RGB888(x_offset+i,y_offset+j);
		}
		for(int j=0;j<thickness;j++)
		{
			for(int i=0;i<v_length;i++)
				FILL_RGB888(x_offset+h_length-j,y_offset+i);
		}
		for(int j=0;j<thickness;j++)
		{
			for(int i=0;i<h_length;i++)
				FILL_RGB888(x_offset+i,y_offset+v_length-j);
		}
		for(int j=0;j<thickness;j++)
		{
			for(int i=0;i<v_length;i++)
				FILL_RGB888(x_offset+j,y_offset+i);
		}*/
		for(int i=0;i<v_length;i++)
		{
			//USINT line_segment(UCHAR* image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , UINT thickness ,UCHAR* color)
			line_segment(image,x_offset,y_offset+i,x_offset+h_length,y_offset+i,1,color);
		}
		a.top.x=x_offset+h_length/2;
		a.top.y=y_offset;
		a.bottom.x=x_offset+h_length/2;
		a.bottom.y=y_offset+v_length;
		a.right.x=x_offset+h_length;
		a.right.y=y_offset+v_length/2;
		a.left.x=x_offset;
		a.left.y=y_offset+v_length/2;	
		a.status=1;
		free(color);
		return a;
	}
}	


/*Draws a straight line between two specified coordinates
Arguments : Image buffer , X offset 1 , Y offset 1 , X offset 2 , Y offset 2 , Thickness , Colour of the line
Returns   : Status of draw
*/
USINT line_segment(UCHAR* image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , UINT thickness ,UCHAR* color)
{
	int xdiff , ydiff ;
	if(x_1>WIDTH || x_2>WIDTH || y_1>HEIGHT || y_2>HEIGHT )
	{
		printf("Invalid co-ordinates");
		return 0;
	}
	float slope;
	float increase;
	int repeat;
	xdiff= ((int)x_1 - (int)x_2);
	ydiff=((int)y_1-(int)y_2);
	if(xdiff!=0)slope=((float)ydiff)/((float)xdiff);
	if(slope<0) repeat= (int)-slope;
	else repeat=(int)slope;
	if(xdiff<0) 
	{
		for(int i=0;i<=(-xdiff);i++)
		{
			increase=slope*(float)i;
			//printf(" %d , %d \n",x_1+i,(int)((float)y_1+increase));
			if(ydiff!=0)
			{
				for(int k=0;k<repeat+1;k++)
				for(int j=0;j<thickness;j++)
					FILL_RGB888(x_1+i+j,(int)((float)y_1+increase+k));
			}
			else
			{
				for(int k=0;k<repeat+1;k++)
				for(int j=0;j<thickness;j++)
					FILL_RGB888(x_1+i,(int)((float)y_1+increase+k+j));
			}
		}
	}
	else if(xdiff>0)
	{
		for(int i=0;i<=(xdiff);i++)
		{
			increase=slope*i;
			//printf(" %d , %d \n",x_2+i,y_2+(int)(increase));
			if(ydiff!=0)
			{
				for(int k=0;k<repeat+1;k++)
				for(int j=0;j<thickness;j++)
					FILL_RGB888(x_2+i+j,((int)y_2+(int)increase+k));
			}
			else
			{
				for(int k=0;k<repeat+1;k++)
				for(int j=0;j<thickness;j++)
					FILL_RGB888(x_2+i,((int)y_2+(int)increase+k+j));
			}
		}	
	}
	else
	{
		if(ydiff<0) { increase=-1;ydiff=-ydiff;}
		else	increase=1;
		for(int i=0;i<=ydiff;i++)
		{	
			//printf(" %d , %d \n",x_1,y_2+(int)(i*increase));
			for(int j=0;j<thickness;j++)	
			FILL_RGB888(x_1+j,((int)y_2+(int)(i*increase)));	
		}
	}
	return 1;
}


/*
Function to fill values in the buffer to draw a paralellogram
Arguments : Image buffer , X offset , Y offset of the topleft corner , Angle of tilt , length , breadth , thickness
Returns   : Status of the draw operation
*/
positions paralellogram(UCHAR *image,UINT x_offset,UINT y_offset,int angledeg,UINT h_length,UINT v_length,UINT thickness)
{
	UCHAR *color=assign_RGB888(BLUE);
	h_length*=10;
	v_length*=10;
	float sine,cosine;
	int startx,starty,endx,endy;
	positions a;
	a.status=0;
	if((x_offset+h_length)>WIDTH || (y_offset+v_length)>HEIGHT )
	{
		printf(" Insufficient image size");
		return a;
	}
	if(angledeg<-360 || angledeg>360)
	{
		printf("Enter a valid angle between -360 to +360 ");
		return a;
	}
	float angle=((float)angledeg*(float)3.14/(float)180);
	printf("%f  ",angle);
	printf("%f  %f \n",cos(angle),sin(angle));
	sine=sin(angle);
	cosine=cos(angle);
	endy=(int)((float)v_length*(float)sine);
	for(int i=0;i<=endy;i++)
	{
		//USINT line_segment(UCHAR* image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , UINT thickness ,UCHAR* color)
		startx=(int)((float)x_offset+((float)i*(float)cosine));
		endx=startx+h_length;
		line_segment(image,startx,y_offset+i,endx,y_offset+i,1,color);
	}
	
	startx=x_offset;starty=y_offset;
	endx=startx+h_length;endy=starty;
	a.top.x=x_offset+h_length/2;
	a.top.y=y_offset;
	//line_segment(image,startx,starty,endx,endy,thickness,color);
	startx=endx;starty=endy;
	endx=(int)((float)startx+((float)v_length*(float)cosine));
	endy=(int)((float)starty+((float)v_length*(float)sine));
	a.right.x=(startx+endx)/2;
	a.right.y=(starty+endy)/2;
	//line_segment(image,startx,starty,endx,endy,thickness,color);
	startx=endx;starty=endy;
	endx=startx-h_length;endy=starty;
	a.bottom.x=(startx+endx)/2;
	a.bottom.y=(starty+endy)/2;
	//line_segment(image,startx,starty,endx,endy,thickness,color);
	startx=endx;starty=endy;
	endx=x_offset;endy=y_offset;
	a.left.x=(startx+endx)/2;
	a.left.y=(starty+endy)/2;
	//line_segment(image,startx,starty,endx,endy,thickness,color);
	a.status=1;
	free(color);
	return a;
}


/*
Function to fill the values draw a rhombus
Arguments : Image buffer , X Offset ,Y offset of the top corner , size , thickness
Returns   : Status of the draw operation
*/
positions rhombus(UCHAR* image, UINT x_offset , UINT y_offset , UINT size , UINT thickness )
{
	UCHAR *color=assign_RGB888(BROWN);
	size=10*size;
	positions a;
	a.status=0;
	if((x_offset+size)>WIDTH || (y_offset+size)>HEIGHT )
	{
		printf(" Insufficient image size");
		return a;
	}
	float increase=(float)size/(float)1.414;
	printf("%f",increase);
	printf(" %d %d %d %d \n",x_offset,y_offset,x_offset+(int)increase,y_offset+(int)increase);
	FILL_RGB888(x_offset,y_offset);
	for(int i=1;i<=increase;i++)
	{
		line_segment(image,x_offset-i,y_offset+i,x_offset+i,y_offset+i,1,color);
	}
	for(int i=increase-1;i>0;i--)
	{
		line_segment(image,x_offset-i,y_offset+(2*increase)-i,x_offset+i,y_offset+(2*increase)-i,1,color);
	}
	FILL_RGB888(x_offset,y_offset+(int)((float)2*increase));
	//line_segment(image,x_offset,y_offset,x_offset+(int)increase,y_offset+(int)increase,thickness,color);
	//line_segment(image,x_offset+(int)increase,y_offset+(int)increase,x_offset,y_offset+(int)((float)2*increase),thickness,color);
	//line_segment(image,x_offset,y_offset+(int)((float)2*increase),x_offset-increase,y_offset+increase,thickness,color);
	//line_segment(image,x_offset-increase,y_offset+increase,x_offset,y_offset,thickness,color);
	a.status=1;
	a.top.x=x_offset;
	a.top.y=y_offset;
	a.bottom.x=x_offset;
	a.bottom.y=y_offset+(int)((float)2*increase);
	a.right.x=x_offset+(int)increase;
	a.right.y=y_offset+(int)increase;
	a.left.x=x_offset-(int)increase;
	a.left.y=y_offset+(int)increase;
	free(color);
	return a;
}


/* Function to fill values to draw an arrowhead
Arguments : Image buffer , X coordinate , Y coordinates of start and end , First direction
Returns   : Status of the draw operation
*/
positions arrow(UCHAR *image, UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , USINT first )
{
	UCHAR* color=assign_RGB888(SEA_GREEN);
	positions a;
	a.status=0;
	a.top.x=x_1;
	a.top.y=y_1;
	if(x_1==x_2 && y_1==y_2)
		return a;
	if(first==HORIZONTAL_FIRST)
	{
		if(line_segment(image,x_1,y_1,x_2,y_1,1,color)==1)
		{
			if(line_segment(image,x_2,y_1,x_2,y_2,1,color)==1)
			{
				printf("Entered %d , %d\n",y_2,y_1);
				if(y_2>y_1)
				{
					for(int i=1;i<=3;i++)
					{
						for(int j=0;j<(2*i+1);j++)
						{
							FILL_RGB888(x_2-i+j,y_2-i);
						}
					}
				}
				else if(y_2<y_1)
				{
					for(int i=1;i<=3;i++)
					{
						for(int j=0;j<(2*i+1);j++)
						{
							FILL_RGB888(x_2-i+j,y_2+i);							
						}
					}
				}
				else
				{
					arrow(image,x_2,y_2,x_2,y_2,VERTICAL_FIRST);
				}
				a.bottom.x=x_2;
				a.bottom.y=y_2;
				free(color);
				a.status=1;
				return a;
			}
			else
			{
				free(color);
				return a;
			}

		}
		free(color);
		return a;
	}
	else
	{
		if(line_segment(image,x_1,y_1,x_1,y_2,1,color)==1)
		{
			if(line_segment(image,x_1,y_2,x_2,y_2,1,color)==1)
			{
				if(x_2>x_1)
				{
					for(int i=1;i<=3;i++)
					{
						for(int j=0;j<(2*i+1);j++)
						{
							FILL_RGB888(x_2-i,y_2-i+j);
						}
					}
				}
				else if(x_2<x_1)
				{
					for(int i=1;i<=3;i++)
					{
						for(int j=0;j<(2*i+1);j++)
						{
							FILL_RGB888(x_2-i,y_2+i+j);
						}
					}
				}
				else
				{
					arrow(image,x_2,y_2,x_2,y_2,HORIZONTAL_FIRST);
				}
				a.bottom.x=x_2;
				a.bottom.y=y_2;
				free(color);
				a.status=1;
				return a;
			}
			else
			{
				free(color);
				return a;
			}
		}
		free(color);
		return a;
	}
}



//Function to fill values to generate a triple bend arrow
//Arguments :Image buffer , X,Y coordinates of start and end points , First direction
//Returns   : Status of draw operation
positions tb_arrow(UCHAR* image,UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , USINT first, USINT side)
{	
	UCHAR *color=assign_RGB888(ORANGE);
	positions a;
	a.status=0;
	int x_changed;
	int y_changed;
	//static int offset=8;
	int change=0;
	if(x_1==x_2 && y_1==y_2)
		return a;
	if(side==RIGHT)
			change=(roffset=roffset+8);
		else
			change=-(loffset=loffset+8);

	a.top.x=x_1;
	a.top.y=y_1;
	if(first==HORIZONTAL_FIRST)
	{
		if(x_2>x_1)
		{
			if(side==RIGHT)
				x_changed=x_2+change;
			else
				x_changed=x_1+change;
		}
		else
		{
			if(side==RIGHT)
				x_changed=x_1+change;
			else
				x_changed=x_2+change;
		}
		if(line_segment(image,x_1,y_1,x_changed,y_1,ARROW_THICK,color)==1)
		{
			if(line_segment(image,x_changed,y_1,x_changed,y_2,ARROW_THICK,color)==1)
			{
				if(line_segment(image,x_changed,y_2,x_2,y_2,ARROW_THICK,color)==1)
				{
					if(side==RIGHT)
					{
					for(int i=1;i<=3;i++)
					{
						for(int j=0;j<(2*i+1);j++)
						{
							FILL_RGB888(x_2+i,y_2-i+j);							
						}
					}
					}
					else
					{
						for(int i=1;i<=3;i++)
						{
							for(int j=0;j<(2*i+1);j++)
							{
								FILL_RGB888(x_2-i,y_2-i+j);								
							}
						}
					}
					a.bottom.x=x_2;
					a.bottom.y=y_2;
					a.status=1;
					free(color);
					return a;
				}
				else
				{
					free(color);
					return a;
				}
			}
			else
			{
				free(color);
				return a;
			}
		}
	}
	else
	{
		if(y_2>y_1)
		{
			if(side==UP)
				y_changed=y_1+change;
			else
				y_changed=y_2+change;
		}
		else
		{
			if(side==UP)
				y_changed=y_2+change;
			else
				y_changed=y_1+change;
		}
		if(line_segment(image,x_1,y_1,x_1,y_changed,ARROW_THICK,color)==1)
		{
			if(line_segment(image,x_1,y_changed,x_2,y_2+change,ARROW_THICK,color)==1)
			{
				if(line_segment(image,x_2,y_changed,x_2,y_2,ARROW_THICK,color)==1)
				{
					if(side==UP)
					{
					for(int i=1;i<=3;i++)
					{
						for(int j=0;j<(2*i+1);j++)
						{
							FILL_RGB888(x_2-i+j,y_2-i);							
						}
					}
					}
					else
					{
						for(int i=1;i<=3;i++)
						{
							for(int j=0;j<(2*i+1);j++)
							{
								FILL_RGB888(x_2-i+j,y_2+i);
							}
						}
					}
					a.bottom.x=x_2;
					a.bottom.y=y_2;
					a.status=1;
					free(color);
					return a;
				}
				else
				{
					free(color);
					return a;
				}
			}
			free(color);
			return a;
		}
		free(color);
		return a;
	}
	free(color);
	return a;
}

//Function to fill values to draw a triply bent arrow
//Arguments : Image buffer, X,Y coordinates of start and end points , First direction , First side
//Returns      : Structure consisiting of position of start and end of the arrow
positions trb_arrow(UCHAR* image,UINT x_1 , UINT y_1 , UINT x_2 , UINT y_2 , USINT first, USINT side)
{
	UCHAR* color=assign_RGB888(RED);
	//static int offset=8;
	int change=0;
	int a_offset;
	int x_changed;
	int y_changed;
	USINT line;
	positions a;
	a.top.x=x_1;
	a.top.y=y_1;
	if(side==RIGHT )
		change=(roffset=roffset+8);
	else
		change=-(loffset=loffset+8);
	if(first==HORIZONTAL_FIRST )
	{	
		
		if(y_2>=y_1)
			a_offset=-10;
		else
			a_offset=10;
		if(x_2>x_1)
		{
			if(side==RIGHT)
				x_changed=x_2+change;
			else
				x_changed=x_1+change;
		}
		else
		{
			if(side==RIGHT)
				x_changed=x_1+change;
			else
				x_changed=x_2+change;
		}
			
		line=line_segment(image,x_1,y_1,x_changed,y_1,ARROW_THICK,color);
		VALID_LINE(line,a);
		line=line_segment(image,x_changed,y_1,x_changed,y_2+a_offset,ARROW_THICK,color);
		VALID_LINE(line,a);
		line=line_segment(image,x_changed,y_2+a_offset,x_2,y_2+a_offset,ARROW_THICK,color);
		VALID_LINE(line,a);
		line=line_segment(image,x_2,y_2+a_offset,x_2,y_2,ARROW_THICK,color);
		VALID_LINE(line,a);
		if(y_2>=y_1)
		{
			for(int i=1;i<=3;i++)
			{
				for(int j=0;j<(2*i+1);j++)
				{
					FILL_RGB888(x_2-i+j,y_2-i);					
				}	
			}
		}
		else
		{
			for(int i=1;i<=3;i++)
			{
				for(int j=0;j<(2*i+1);j++)
				{
					FILL_RGB888(x_2-i+j,y_2+i);				
				}	
			}
		}
		
	}
	else
	{
		if(x_2>=x_1)
			a_offset=10;
		else
			a_offset=-10;
		if(y_2>y_1)
		{
			if(side==DOWN)
				y_changed=y_2+change;
			else
				y_changed=y_1+change;
		}
		else
		{
			if(side==DOWN)
				y_changed=y_1+change;
			else
				y_changed=y_2+change;
		}
			
		line=line_segment(image,x_1,y_1,x_1,y_changed,ARROW_THICK,color);
		VALID_LINE(line,a);
		line=line_segment(image,x_1,y_changed,x_2+a_offset,y_changed,ARROW_THICK,color);
		VALID_LINE(line,a);
		line=line_segment(image,x_2+a_offset,y_changed,x_2+a_offset,y_2,ARROW_THICK,color);
		VALID_LINE(line,a);
		line=line_segment(image,x_2+a_offset,y_2,x_2,y_2,ARROW_THICK,color);
		VALID_LINE(line,a);
		
		if(x_2<=x_1)
		{
			for(int i=1;i<=3;i++)
			{
				for(int j=0;j<(2*i+1);j++)
				{
					FILL_RGB888(x_2-i,y_2-i+j);
				}	
			}
		}
		else
		{
			for(int i=1;i<=3;i++)
			{
				for(int j=0;j<(2*i+1);j++)
				{
					FILL_RGB888(x_2+i,y_2-i+j);					
				}	
			}
		}
	}
	a.bottom.x=x_2;
	a.bottom.y=y_2;
	a.status=1;
	free(color);
	return a;
}
		
/*
Function to fill values in the buffer to draw a rounded rectangle
Arguments : Image buffer, X offset , Y offset of midpoint of top side , horizontal length , vertical length 
Returns   : Status of the draw operation
*/
positions round_rect(UCHAR *image,UINT x_offset , UINT y_offset , UINT h_length , UINT v_length)
{
	UCHAR *color=assign_RGB888(VIOLET);
	h_length*=10;
	v_length*=10;
	positions a;
	int halfh_len=h_length/2;
	for(int i=0;i<=10;i++)
	{
		line_segment(image,x_offset-halfh_len+10,y_offset+i,x_offset+halfh_len-10,y_offset+i,1,color);
	}
	for(int i=0;i<=10;i++)
	{
		line_segment(image,x_offset-halfh_len+10,y_offset+i+v_length-10,x_offset+halfh_len-10,y_offset+i+v_length-10,1,color);
	}
	for(int i=0;i<=(v_length-20);i++)
	{
		line_segment(image,x_offset-halfh_len,y_offset+10+i,x_offset+halfh_len,y_offset+10+i,1,color);
	}
	//line_segment(image,(x_offset-h_length/2+10),y_offset,(x_offset+h_length/2-10),y_offset,2,color);
	//line_segment(image,x_offset-h_length/2,(y_offset+10),x_offset-h_length/2,(y_offset+v_length-10),2,color);
	//line_segment(image,x_offset+h_length/2,(y_offset+10),x_offset+h_length/2,(y_offset+v_length-10),2,color);
	//line_segment(image,(x_offset-h_length/2+10),y_offset+v_length,(x_offset+h_length/2-10),y_offset+v_length,2,color);
	draw_arc(image,(x_offset-h_length/2+10),(y_offset+10),1,SECOND);
	draw_arc(image,(x_offset+h_length/2-10),(y_offset+10),1,FIRST);
	draw_arc(image,(x_offset-h_length/2+10),(y_offset+v_length-10),1,THIRD);
	draw_arc(image,(x_offset+h_length/2-10),(y_offset+v_length-10),1,FOURTH);
	a.top.x=x_offset;
	a.top.y=y_offset;
	a.bottom.x=x_offset;
	a.bottom.y=y_offset+v_length;
	a.right.x=x_offset+h_length/2;
	a.right.y=y_offset+v_length/2;
	a.left.x=x_offset-h_length/2;
	a.left.y=y_offset+v_length/2;
	a.status=1;
	free(color);
	return a;	
}
