 #ifndef _STDIO_H
 #include<stdio.h>
 #endif
 #ifndef _STDLIB_H
 #include<stdlib.h>
 #endif
 #ifndef _STRING_H
 #include<string.h>
 #endif
 #ifndef _IMAGING_H
 #include"imaging.h"
 #endif
 #ifndef _FLOW_H
 #include"flow.h"
 #endif
 #ifndef _MATH_H
 #include<math.h>
 #endif

#define ZERO_XS 497
#define ZERO_YS 497

#define WRITE_FILE 	"Endpoints.bmp"


 element *head=NULL,*current=NULL;
 int max_cols=0;
 int HEIGHT=0; 
 int row=1;
 //Function which fills the values in the image buffer  to draw the flowchart from the given root and starting point
 //Arguments : Image buffer , Root element , Start position of the root
 //Returns   : Structure containing useful positions of the end element
positions drawshape (UCHAR* image, element* root,positions start,int maxcols )
{
	printf(" Into shapes \n");
	int R_R_Hlen=6,R_R_Vlen=3;
	positions points=start,dummy,contin;
	while(root!=NULL)
	{
	printf(" Into while\n");
		switch(root->type)
		{
			case TERMINATORS :
									{	
									printf("In terminator\n");
										if(root->top==NULL)
										{
											root->pos=round_rect(image,points.top.x,points.top.y,R_R_Hlen,R_R_Vlen);								
											points=root->pos;
											if(root->yes->element_id > root->element_id)
											{
												points=arrow(image,points.bottom.x,points.bottom.y,points.bottom.x,points.bottom.y+20,HORIZONTAL_FIRST);
												root=root->yes;
											}
											else
											{	
												if(root->yes->type != DECISION)
												dummy=trb_arrow(image,points.bottom.x,points.bottom.y,root->yes->pos.left.x,root->yes->pos.left.y,VERTICAL_FIRST,DOWN);
											else
												dummy=trb_arrow(image,points.bottom.x,points.bottom.y,root->yes->pos.top.x,root->yes->pos.top.y-5,VERTICAL_FIRST,DOWN);
												contin=points;
												root=NULL;
											}
											
										}
										else
										{
											printf(" %d %d \n",points.bottom.x,points.bottom.y);
											root->pos=round_rect(image,points.bottom.x,points.bottom.y,R_R_Hlen,R_R_Vlen);
											printf(" before nulling \n");
											contin=root->pos;
											root=NULL;
										}
									}break;
			case PROCESS          :
									{
									printf(" In process\n");
										root->pos=drawrectangle(image,points.bottom.x-30,points.bottom.y,6,4,2);
										points=root->pos;
										if(root->yes->element_id > root->element_id)
										{
											points=arrow(image,points.bottom.x,points.bottom.y,points.bottom.x,points.bottom.y+20,HORIZONTAL_FIRST);
											root=root->yes;
										}
										else
										{
											if(root->yes->type != DECISION)
											dummy=trb_arrow(image,points.bottom.x,points.bottom.y,root->yes->pos.left.x,root->yes->pos.left.y,VERTICAL_FIRST,DOWN);
										else
												dummy=trb_arrow(image,points.bottom.x,points.bottom.y,root->yes->pos.top.x,root->yes->pos.top.y-5,VERTICAL_FIRST,DOWN);
											contin=points;
											root=NULL;
										}
									}break;
			case IO				:
									{
									printf(" In IO\n");
										root->pos=paralellogram(image,points.bottom.x-30,points.bottom.y,110,6,6,2);
										points=root->pos;
										if(root->yes->element_id > root->element_id)
										{
											points=arrow(image,points.top.x,points.bottom.y,points.top.x,points.bottom.y+20,HORIZONTAL_FIRST);
											root=root->yes;
										}
										else
										{
											if(root->yes->type != DECISION)
											dummy=trb_arrow(image,points.bottom.x,points.bottom.y,root->yes->pos.left.x,root->yes->pos.left.y,VERTICAL_FIRST,DOWN);
										else
												dummy=trb_arrow(image,points.bottom.x,points.bottom.y,root->yes->pos.top.x,root->yes->pos.top.y-5,VERTICAL_FIRST,DOWN);
											contin=points;
											root=NULL;
										}
									}break;
			case DECISION          :
									{
									printf("In Decision\n");
										root->pos=rhombus(image,points.bottom.x,points.bottom.y,6,2);
										points=root->pos;
										if(root->yes != NULL && root->yes->element_id > root->element_id)
										{
											points=trb_arrow(image,points.left.x,points.left.y,points.top.x,points.bottom.y+30,HORIZONTAL_FIRST,LEFT);
											contin=drawshape(image,root->yes,points,maxcols);
										}
										else
										{
											if(root->yes->type != DECISION)
												dummy=tb_arrow(image,points.left.x,points.left.y,root->yes->pos.left.x,root->yes->pos.left.y,HORIZONTAL_FIRST,LEFT);
											else
												dummy=tb_arrow(image,points.left.x,points.left.y,root->yes->pos.top.x,root->yes->pos.top.y-5,HORIZONTAL_FIRST,LEFT);
											contin=root->pos;
										}
										points=root->pos;
										if(root->no != NULL && root->no->element_id > root->element_id)
										{
											
											points=trb_arrow(image,points.right.x,points.right.y,contin.bottom.x,contin.bottom.y+50,HORIZONTAL_FIRST,RIGHT);
											contin=drawshape(image,root->no,points,maxcols);
											root=NULL;
										}	
										else
										{
										printf("Inside no block 2\n");
										if(root->no!=NULL)
										{
										if(root->no->type != DECISION)
											dummy=tb_arrow(image,points.right.x,points.right.y,root->no->pos.right.x,root->no->pos.right.y,HORIZONTAL_FIRST,RIGHT);
											else
												dummy=tb_arrow(image,points.right.x,points.right.y,root->no->pos.top.x,root->no->pos.top.y-5,HORIZONTAL_FIRST,RIGHT);
											contin=points;
											root=NULL;
										}
										}
									}break;
			}
		}	
		return contin;
}
	
//Function to clear all the elements in the tree
//Arguments :  Root element
//Returns   :  None	
void freetree(element *root)
{
	printf(" Inside freetree %p\n",root);
	element *base=root;
	element * temp;
	while(root!= NULL && root->yes !=NULL)
	{
		if(root->no != NULL)
		{
			if(root->no->element_id>root->element_id)freetree(root->no);
			printf("Freeing no\n");
		}	
		printf("%d\n",root);
		if(root->yes->element_id>root->element_id)root=root->yes;
		else break;
	}
	while(root!=base)
	{
		temp=root;
		printf("Freeing %d\n",root->element_id);
		root=root->top;
		free(temp);
	}
	return;
}
	



int main(void)
{
	UCHAR *image;//=(UCHAR*)malloc(WIDTH*(BPP_MONO/8)*HEIGHT*sizeof(UCHAR));
	UCHAR *imagedup;
	int choice;
 	printf("\t\t\tWelcome to Flowchart generator !!! \n");
 	printf(" \n\nStart Drawing flowchart ? 1=Yes/0=No ");
 	scanf("%d",&choice);
 	if(choice==1)
 	{
 		head=create_element(TERMINATORS,1,NULL);	
 		current=head;
 		display_elements(head);
 		max_cols=add_elements(head,YES_BRANCH);
 		HEIGHT=85*row;
 		image=(UCHAR*)malloc(WIDTH*(BPP_RGB888/8)*HEIGHT*sizeof(UCHAR));
 		imagedup=image;
		drawaxis(image);
		positions start;
		start.top.x=500;
		start.top.y=50;
		printf("After Assignment\n");
		drawshape(image,head,start,max_cols);
		printf("After shapes\n");
		freetree(head);
		free(head);
		printf(" Trees freed ! ");
		fill_header(WRITE_FILE,HEIGHT,WIDTH,BPP_RGB888,999,0);
		//fill_pallete(WRITE_FILE);
		printf("Before Write\n");
		FILE *fp=fopen(WRITE_FILE,APPEND_BIN);
		fwrite(image,HEIGHT*WIDTH*BPP_RGB888/8,1,fp);
		fclose(fp);
		printf("After Write\n");
		free(imagedup);	
	}
}
